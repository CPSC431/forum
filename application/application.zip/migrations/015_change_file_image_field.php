<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Migration_Change_File_Image_Field extends CI_Migration {

	public function up()
	{
		

	}

	public function down()
	{
		
	}
}